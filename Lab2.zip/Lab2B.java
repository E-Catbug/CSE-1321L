/*Class: CSE 1321L
        Section: WJ1
        Term: fall 2022
        Instructor: Nick Murphy
        Name: Takeria Thompson
        Lab#: 2
*/
public class Lab2B {
    public static void main (String[] args)
    {
        System.out.println("___*___");
        System.out.println("__*_*__");
        System.out.println("_*_*_*_");
        System.out.println("*_*_*_*");
        System.out.println("_*_*_*_");
        System.out.println("__*_*__");
        System.out.println("___*___");
    }
}

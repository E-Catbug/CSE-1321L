/*
Class: CSE 1321L
Section: WJ1
Term: FALL22
Instructor: Nick Murphy
Name: Takeria Thompson
Lab#: 1
*/
public class Lab1A
{
    // Prints two lines of output representing a rocket countdown.
    public static void main(String[] args)
    {
        System.out.print ("Three... ");
        System.out.print ("Two... ");
        System.out.print ("One... ");
        System.out.print ("Zero... ");
        System.out.println ("Liftoff!"); // appears on first line
        System.out.println ("Houston, we have a problem.");
    }
}